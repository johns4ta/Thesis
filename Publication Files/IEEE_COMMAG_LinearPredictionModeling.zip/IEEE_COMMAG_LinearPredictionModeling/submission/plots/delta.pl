#!perl -W
use strict;
use List::Util qw(min max);
use Cwd;

my @dirs =  ( 'June 15 2013 Results','March 15 2014 Results','August 15 2014 Results','January 15 2015 Results' );
foreach my $dir (@dirs) {
	chdir($dir);
	
	
	foreach my $subdir ('30 second bins', '300 second bins','3600 second bins') {
		chdir($subdir);
		
		print getcwd()."\n";

		my $actual = "actual_data_graphing_info.csv";
		my $simul  = "sim_data_graphing_info.csv";

		print "$actual\n";

		my @real;
		open IN, "<$actual" or die "$!";
		while (<IN>) {
			next if /^#/;
			chomp;
			my @line = split ",";
			next if $line[0] eq "Time";
			push @real , [ @line ];
		}
		close(IN);

		my @sim;
		open IN, "<$simul" or die "$!";
		while (<IN>) {
			next if /^#/;
			chomp;
			my @line = split ",";
			next if $line[0] eq "Time";
			push @sim , [ @line ];
		}
		close(IN);

		open OUT, ">delta.csv" or die;
		for my $i (0 .. min($#sim,$#real)) {
			my @reall = @{ $real[$i] };
			my @siml = @{ $sim[$i] };
	
			print OUT "$i";
			for my $j (0 .. $#siml) {
				if ($reall[$j] != 0) {
					print OUT ", ".(($siml[$j] - $reall[$j]));
				}
				else {
					print OUT ", 0";
				}
			}
			print OUT "\n";
		}
		close OUT;
		
		chdir("..");
	}
	
	chdir("..");
}

exit 0;