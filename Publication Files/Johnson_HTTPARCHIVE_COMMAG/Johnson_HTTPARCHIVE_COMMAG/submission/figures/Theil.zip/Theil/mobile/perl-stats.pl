#!perl
use strict;
use warnings;
use Statistics::Basic qw(:all);
use Number::Format qw(:subs :vars);
use DateTimeX::Easy;
$THOUSANDS_SEP   = '';
$DECIMAL_POINT   = '.';

my @header = ("pageid","createDate","archive","label","crawlid","wptid","wptrun","url","urlShort","cdn","startedDateTime","TTFB","renderStart",
"onContentLoaded","onLoad","fullyLoaded","visualComplete","PageSpeed","SpeedIndex","rank","reqTotal","reqHtml","reqJS","reqCSS",
"reqImg","reqGif","reqJpg","reqPng","reqFont","reqFlash","reqJson","reqOther","bytesTotal","bytesHtml","bytesJS","bytesCSS",
"bytesImg","bytesGif","bytesJpg","bytesPng","bytesFont","bytesFlash","bytesJson","bytesOther","bytesHtmlDoc",
"numDomains","maxDomainReqs","numRedirects","numErrors","numGlibs","numHttps","numCompressed","numDomElements",
"maxageNull","maxage0","maxage1","maxage30","maxage365","maxageMore",
"gzipTotal","gzipSavings");
  
my @files = <*.csv>;
open OUT, ">./overview.csv" or die "$!";
print OUT "# date, ";
for my $item (9 .. $#header) {
	print OUT "$header[$item] (AVG), $header[$item] (STD), ";
}
print OUT "\n";

foreach my $file (@files) {
	next if $file =~ /overview/;
	print "$file: ";

	my %itemhash;
	open IN, "<$file" or die "$!";
READ: while (<IN>) {		
		chomp;		
		my @line = split ",";		
		for my $item (0 .. $#line) {
			my @helper;
			@helper = @{ $itemhash{$item} } if defined($itemhash{$item});
			#print "@helper\n";
			$helper[++$#helper] = $line[$item]; #append			
			$itemhash{$item} = [ @helper ];
		}				
	}
	close IN;
	
	$file =~ s/\-M\.csv//;	
	$file =~ s/\-F\.csv//;
	my $date =  DateTimeX::Easy->new($file);
	
	print OUT "$date,";
	for my $item (10 .. $#header) {
		my $ref = $item-2;
		my @helper = @{ $itemhash{$ref} };
		for my $i (0 .. $#helper) {
			$helper[$i] = 0 if $helper[$i] eq "";
			$helper[$i] = 0 if $helper[$i] eq '\N';
		}
		print OUT (mean(\@helper)+0).",".(stddev(\@helper)+0).",";
	}
	print OUT "\n";
}
close OUT;