#!perl
use strict;
use warnings;
use Statistics::Basic qw(:all);
use Number::Format qw(:subs :vars);
use DateTimeX::Easy;
$THOUSANDS_SEP   = '';
$DECIMAL_POINT   = '.';
$|=1;

my @header = ("urlShort","cdn","startedDateTime","TTFB","renderStart","onContentLoaded","onLoad","fullyLoaded","visualComplete","PageSpeed","SpeedIndex","rank","reqTotal","reqHtml","reqJS","reqCSS","reqImg","reqGif","reqJpg","reqPng","reqFont","reqFlash","reqJson","reqOther","bytesTotal","bytesHtml","bytesJS","bytesCSS",
"bytesImg","bytesGif","bytesJpg","bytesPng","bytesFont","bytesFlash","bytesJson","bytesOther","bytesHtmlDoc",
"numDomains","maxDomainReqs","numRedirects","numErrors","numGlibs","numHttps","numCompressed","numDomElements",
"maxageNull","maxage0","maxage1","maxage30","maxage365","maxageMore", "gzipTotal","gzipSavings");
  
my @files = <*.csv>;
open OUT, ">./overview.csv" or die "$!";
print OUT "# date, ";
for my $item (2 .. $#header) {
	print OUT "$header[$item] (AVG), $header[$item] (STD), ";
}
print OUT "\n";

foreach my $file (@files) {
	next if $file =~ /overview/;
	print "$file: ";

	my %itemhash;
	open IN, "<$file" or die "$!";
READ: while (<IN>) {		
		chomp;		
		my @line = split ",";		
		# find the right-most "http://"
		my $leftcell = 0;		
		for (my $needle=$#line;$needle>0;$needle--) {
			if ($line[$needle] =~ m/^(http:\/\/)/ ) {
				$leftcell = $needle;
				last;
			}
		}
    my @line2;
    for my $i ($leftcell .. $#line) {
        $line2[++$#line2] = $line[$i];
    } 
   
		for my $item (0 .. $#line2) {
			my @helper;
			@helper = @{ $itemhash{$item} } if defined($itemhash{$item});
			#print "@helper\n";
			$helper[++$#helper] = $line2[$item]; #append			
			$itemhash{$item} = [ @helper ];
		}				
	}
	close IN;
	
	$file =~ s/\-M\.csv//;	
	$file =~ s/\-F\.csv//;
	my $date =  DateTimeX::Easy->new($file);
	
	print OUT "$date,";
	for my $item (2 .. $#header) {
		my $ref = $item;
		my @helper = @{ $itemhash{$ref} };
		for my $i (0 .. $#helper) {
			$helper[$i] = 0 if $helper[$i] eq "";
			$helper[$i] = 0 if $helper[$i] eq '\N';
		}
		print OUT (mean(\@helper)+0).",".(stddev(\@helper)+0).",";
	}
	print OUT "\n";
}
close OUT;