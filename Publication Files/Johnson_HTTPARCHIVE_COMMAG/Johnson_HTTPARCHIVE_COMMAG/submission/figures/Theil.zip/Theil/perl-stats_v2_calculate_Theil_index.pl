#!perl
use strict;
use warnings;
#use diagnostics;

use Data::Dumper;
use Statistics::Basic qw(:all);
use Number::Format qw(:subs :vars);
use DateTimeX::Easy;
use Text::CSV_XS;

$THOUSANDS_SEP   = '';
$DECIMAL_POINT   = '.';
$|=1;

my @header = ("urlShort","cdn","startedDateTime","TTFB","renderStart","onContentLoaded","onLoad","fullyLoaded","visualComplete","PageSpeed","SpeedIndex","rank","reqTotal","reqHtml","reqJS","reqCSS","reqImg","reqGif","reqJpg","reqPng","reqFont","reqFlash","reqJson","reqOther","bytesTotal","bytesHtml","bytesJS","bytesCSS",
"bytesImg","bytesGif","bytesJpg","bytesPng","bytesFont","bytesFlash","bytesJson","bytesOther","bytesHtmlDoc",
"numDomains","maxDomainReqs","numRedirects","numErrors","numGlibs","numHttps","numCompressed","numDomElements",
"maxageNull","maxage0","maxage1","maxage30","maxage365","maxageMore", "gzipTotal","gzipSavings");

my @files = <*.csv>;
open OUT, ">./theil_entropy.csv" or die "$!";
my $header = 0;
foreach my $filename (@files) {
	next if $filename =~ /overview/;
	next if $filename =~ /theil/;
	print "$filename: ";
	
	my $csv = Text::CSV_XS->new ({ binary => 1 });
	open my $FHIN, "<", "$filename" or die "$filename: $!";
	my $csvdata = $csv->getline_all($FHIN);
	#DEBUG
	#print Dumper($csvdata);

	# Determine the offset for the URLshort in the first entry's array
	my @sample = @{$csvdata->[0]};
	my $leftcell = 0;		
	for (my $needle=$#sample;$needle>0;$needle--) {
		if ($sample[$needle] =~ m/^(http:\/\/)/ ) {
			$leftcell = $needle;
			last;
		}
	}

	# print header if not done
	if ($header == 0) {
		print OUT "# date, ";
		for my $col ($leftcell + 2 .. $#sample-1) {
			print OUT "".($header[$col - $leftcell]).",";
		}
		print OUT "\n";
		$header++;
	}

	$filename =~ s/\-M\.csv//;	
	$filename =~ s/\-F\.csv//;
	my $date =  DateTimeX::Easy->new($filename);
	print OUT "$date,";
	
	for my $col ($leftcell + 2 .. $#sample-1) {
		# need to create new stats object
		my @stats;
		for my $row (0 .. $#{$csvdata}) {
			$stats[++$#stats] = $csvdata->[$row][$col];		
		}
		my $mean = mean(\@stats)+0;
		my $theil = 0;
		if ($mean > 0 ) {		
			for my $row (0 .. $#{$csvdata}) {
				if ($csvdata->[$row][$col] == 0) {
					$theil += (0.0000000001/$mean) * log(($#{$csvdata}+1)*$mean/0.0000000001);
				}
				else {
					$theil += ($csvdata->[$row][$col]/(($#{$csvdata}+1)*$mean)) * log((($#{$csvdata}+1)*$mean)/$csvdata->[$row][$col]);		
				}
			}		
		}
		print OUT "$theil,";		
	}
	print OUT "\n";
}		