#!perl
use strict;
use warnings;
use Statistics::Basic qw(:all);
use Number::Format qw(:subs :vars);
use DateTimeX::Easy;
$THOUSANDS_SEP   = '';
$DECIMAL_POINT   = '.';
$|=1;

my @header = ("pageid","createDate","archive","label","crawlid","wptid","url","urlShort","cdn","startedDateTime","TTFB","renderStart","onContentLoaded","onLoad","fullyLoaded","visualComplete","PageSpeed","SpeedIndex","rank","reqTotal","reqHtml","reqJS","reqCSS","reqImg","reqGif","reqJpg","reqPng","reqFont","reqFlash","reqJson","reqOther","bytesTotal","bytesHtml","bytesJS","bytesCSS",
"bytesImg","bytesGif","bytesJpg","bytesPng","bytesFont","bytesFlash","bytesJson","bytesOther","bytesHtmlDoc",
"numDomains","maxDomainReqs","numRedirects","numErrors","numGlibs","numHttps","numCompressed","numDomElements",
"maxageNull","maxage0","maxage1","maxage30","maxage365","maxageMore", "gzipTotal","gzipSavings");
  
print $#header."\n";
  
my @files = <*.csv>;
open OUT, ">./overview.csv" or die "$!";

foreach my $file (@files) {
	next if $file =~ /overview/;
	print "$file: ";
	my $file2 = $file;
	$file =~ s/\-M\.csv//;	
	$file =~ s/\-F\.csv//;
	my $date =  DateTimeX::Easy->new($file);

	open IN, "<$file2" or die "$!";
READ: while (<IN>) {		
		chomp;		
		my $linestr = $_;
		my @line = split ",";	
		if ($#line != $#header) {
			print OUT "$date, $#line\n";
			for my $i (0 .. $#header) {
				print OUT "$header[$i],";
			}
			print OUT "\n$linestr\n";		
		}
		
	}
	close IN;
}
close OUT;