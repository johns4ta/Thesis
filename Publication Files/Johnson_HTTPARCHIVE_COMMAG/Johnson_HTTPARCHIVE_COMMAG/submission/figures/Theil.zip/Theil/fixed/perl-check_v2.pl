#!perl
use strict;
use warnings;
use File::Basename;
$THOUSANDS_SEP   = '';
$DECIMAL_POINT   = '.';
$|=1;

my @header = ("urlShort","cdn","startedDateTime","TTFB","renderStart","onContentLoaded","onLoad","fullyLoaded","visualComplete","PageSpeed","SpeedIndex","rank","reqTotal","reqHtml","reqJS","reqCSS","reqImg","reqGif","reqJpg","reqPng","reqFont","reqFlash","reqJson","reqOther","bytesTotal","bytesHtml","bytesJS","bytesCSS",
"bytesImg","bytesGif","bytesJpg","bytesPng","bytesFont","bytesFlash","bytesJson","bytesOther","bytesHtmlDoc",
"numDomains","maxDomainReqs","numRedirects","numErrors","numGlibs","numHttps","numCompressed","numDomElements",
"maxageNull","maxage0","maxage1","maxage30","maxage365","maxageMore", "gzipTotal","gzipSavings");
  
 
my @files = <*.csv>;
mkdir(..
foreach my $file (@files) {
	next if $file =~ /overview/;
	print "$file: ";
	my $file2 = $file;
	$file =~ s/\-M\.csv//;	
	$file =~ s/\-F\.csv//;
	my $date =  DateTimeX::Easy->new($file);

	open IN, "<$file2" or die "$!";
READ: while (<IN>) {		
		chomp;		
		my $linestr = $_;
		my @line = split ",";
		# find the right-most "http://"
		my $leftcell = 0;		
		for (my $needle=$#line;$needle>0;$needle--) {
			if ($line[$needle] =~ m/^(http:\/\/)/ ) {
				$leftcell = $needle;
				last;
			}
		}	

		
		
	}
	close IN;
}
close OUT;